<footer>
	<div class="zerogrid">
		<div class="row">
		<center>
		  <p class="bottom1">|<a href="copyrights.php"> Copyrights Policy </a>|<a href="terms.php"> Terms & Conditions </a>|<a href="privacypolicy.php">Privacy Policy</a>|<a href="help.php"> Help</a>|<a href="hyper.php"> Hyperlink Policy</a>|<a href="sitemap.php"> Sitemap </a>|<a href="brokenlink.php"> Broken Links </a>|<a href="faq.php"> FAQ's </a> | Feedback		
		    </p>
		  </p>
		</center>
		<center>
		</center>
		<center><p class="bottom2"><a href="https://tobaccoboard.com/indexeng.php">Home</a> | <a href="https://tobaccoboard.com/bactivities.php">About Us</a> | <a href="https://tobaccoboard.com/fcvt.php">FCV Tobacco</a> | <a href="https://tobaccoboard.com/tfcv.php">Tobacco Varieties</a> | <a href="https://tobaccoboard.com/exporters.php">Exporters</a> | <a href="https://tobaccoboard.com/circulars.php">Circulars</a> | <a href="https://tobaccoboard.com/vacancies.php">Recruitment</a> | <a href="https://tobaccoboard.com/empcorner.php">Employee Corner</a> | <a href="https://tobaccoboard.com/forms.php">Forms</a> | <a href="https://tobaccoboard.com/contactus1.php">Contact Us</a>|</p>
		</center>
		<center><marquee><p><img src="images/indiagov.jpg"><img src="images/swatch.jpg"><img src="images/g20.jpg"><img src="images/digitalindia.jpg"><img src="images/gatisakthi.jpg"> <img src="images/commerce.jpg"> <img src="images/rti.jpg"></p></marquee></center>
		<center><p class="bottom3">This is the official website of Tobacco Board of India an autonomous body under Ministry of Commerce & Industry, Govt Of India.
© 2023. All Rights Reserved.</p></center>
			<!--<section class="col-1-3">
				<div class="heading">About us</div>
				<div class="content">
					Free Basic Html5 Templates created by <a href="https://www.zerotheme.com">ZEROTHEME</a>. You can use and modify the template for both personal and commercial use. You must keep all copyright information and credit links in the template and associated files.
				</div>
			</section>
			<section class="col-1-3">
				<div class="heading">Categories</div>
				<div class="content">
					<ul>
						<li><a href="https://www.zerotheme.com">Free Html5 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Css3 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Responsive Html5 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Basic Html5 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Layout Html5 Templates</a></li>
					</ul>
				</div>
			</section>
			<section class="col-1-3">
				<div class="heading">Featured Post</div>
				<div class="content">
					<table border="0px">
						<tr>
							<td><img src="images/thumb4.jpg"/></td>
							<td><img src="images/thumb5.jpg"/></td>
							<td><img src="images/thumb6.jpg"/></td>
						</tr>
						<tr>
							<td><img src="images/thumb6.jpg"/></td>
							<td><img src="images/thumb5.jpg"/></td>
							<td><img src="images/thumb4.jpg"/></td>
						</tr>
					</table>
				</div>
			</section>-->
		</div>
	</div>
</footer>