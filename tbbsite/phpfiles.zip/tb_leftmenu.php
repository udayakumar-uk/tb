<div class="sidebar col05">
				<section>
					<div class="content">
						<ul class="list">
							<li><a href="bactivities.php">Board Activities</a></li>
							<li><a href="act.php">Board Act</a></li>
							<li><a href="bmembers.php">Board Members</a></li>
							<li><a href="orgchart.php">Organization Chart</a></li>
							<li><a href="contactus.php">Adminstrative Offices</a></li>
							<li><a href="news.php">News & Events</a></li>
							<li><a href="photogallery.php">Photo Gallery</a></li>
							<li><a href="publications.php">Publications</a></li>
							<li><a href="rta.php">RTI Act</a></li>
							<li><a href="tenders.php">Tenders</a></li>
							<li><a href="forms.php">Forms</a></li>
						</ul>
					</div>
				</section>
				<section>
					<h2 style="border-bottom:2px solid #c66f2f">EMPLOYEE CORNER</h2>
					<div class="content">
						<ul class="list">
							<li><a href="empcorner.php?stype=Transfers%20And%20Postings">Transfers & Postings</a></li>
							<li><a href="empcorner.php?stype=Appointment%20Orders">Appointment Orders</a></li>
							<li><a href="empcorner.php?stype=Promotions">Promotions</a></li>
							<li><a href="empcorner.php?stype=Utility%20Forms">Utility Forms</a></li>
							<li><a href="circulars.php">Circulars & Notifications</a></li>
							</ul>
					</div>
				</section>
				
				
				
			</div>