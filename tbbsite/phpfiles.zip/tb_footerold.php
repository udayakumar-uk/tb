<footer>
	<div class="zerogrid">
		<div class="row">
		<center><p class="bottom">|<a href=""> Copyrights Policy </a>|<a href=""> Terms & Conditions </a>|<a href="">Privacy Policy</a>|<a href=""> Help</a>|<a href=""> Hyperlink Policy</a>|<a href=""> Broken Links </a></p>
		</center>
		<center>
		</center>
		<center><p class="bottom2"><a href="">Home</a>|<a href=""> Disclaimer </a>|<a href=""> Sitemap </a>|<a href="">Contact Us</a>|<a href=""> Feedback</a></p></center>
		<center><marquee><p><img src="images/indiagov.jpg"><img src="images/swatch.jpg"><img src="images/g20.jpg"><img src="images/digitalindia.jpg"><img src="images/gatisakthi.jpg"> <img src="images/commerce.jpg"> <img src="images/rti.jpg"></p></marquee></center>
		<center><p class="bottom3">This is the official website of Tobacco Board of India an autonomous body under Ministry of Commerce & Industry, Govt Of India.
© 2023. All Rights Reserved.</p></center>
			<!--<section class="col-1-3">
				<div class="heading">About us</div>
				<div class="content">
					Free Basic Html5 Templates created by <a href="https://www.zerotheme.com">ZEROTHEME</a>. You can use and modify the template for both personal and commercial use. You must keep all copyright information and credit links in the template and associated files.
				</div>
			</section>
			<section class="col-1-3">
				<div class="heading">Categories</div>
				<div class="content">
					<ul>
						<li><a href="https://www.zerotheme.com">Free Html5 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Css3 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Responsive Html5 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Basic Html5 Templates</a></li>
						<li><a href="https://www.zerotheme.com">Free Layout Html5 Templates</a></li>
					</ul>
				</div>
			</section>
			<section class="col-1-3">
				<div class="heading">Featured Post</div>
				<div class="content">
					<table border="0px">
						<tr>
							<td><img src="images/thumb4.jpg"/></td>
							<td><img src="images/thumb5.jpg"/></td>
							<td><img src="images/thumb6.jpg"/></td>
						</tr>
						<tr>
							<td><img src="images/thumb6.jpg"/></td>
							<td><img src="images/thumb5.jpg"/></td>
							<td><img src="images/thumb4.jpg"/></td>
						</tr>
					</table>
				</div>
			</section>-->
		</div>
	</div>
</footer>