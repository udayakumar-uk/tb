<?php include "header.php";



/*$img=get_gallery();*/



?>



 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">



 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



	<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>



<!------ Include the above in your HEAD tag ---------->







<!--####



### How to add in your boostrap project



1) Add jQuery "<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>"



2) Download fancybox (https://github.com/fancyapps/fancyBox)



3) Or use CDN (http://cdnjs.com/libraries/fancybox)



####--!>







<!-- References: https://github.com/fancyapps/fancyBox -->















<style>



.gallery



{



    display: inline-block;



    margin-top: 20px;



}
</style>



<p>&nbsp;</p>

<div class="container">



	<div class="row">



   



<?php /*?>      <?php 



		if($img>0)



		{



		for($i=0;$i<count($img);$i++)



		{



			print_r($img);



			print_r($img[$i]['images']);#56a559



		?><?php */?>



      <h3 align="left" style="color:#3C9686"><a href="http://angrau.ac.in/angrau/onlineadmission.php" target="_blank">&quot;Second Counseling for Admission into BiPC stream UG courses of ANGRAU, SVVU, Dr.YSRHU for 2019-20</a></h3>
      <h3 align="center" style="color:#337ab7">(including Private Agril./ Hort. Colleges)</h3>
  </div>



</div> 



<p>



  <!-- container / end -->



  <!--<script>



$(document).ready(function(){



    //FANCYBOX



    //https://github.com/fancyapps/fancyBox



    $(".fancybox").fancybox({



        openEffect: "none",



        closeEffect: "none"



    });



});-->

  <strong></strong>&nbsp; &nbsp;&nbsp;</p>

<table width="75%" border="0" align="center">

  <tr>

    <td><p>      <a href="http://angrau.ac.in/angrau/angrau_admissions/File_1new.pdf" target="_blank">1. &quot;Detailed Notification&quot;</a><br />

      2. <a href="http://angrau.ac.in/angrau/angrau_admissions/File_2new.pdf" target="_blank">&quot;Seat Vacancy Position&quot;</a><br />

      <a href="http://angrau.ac.in/angrau/angrau_admissions/File_3new.pdf">3. &quot;CAP Quota - Provisional Priority List&quot; - </a><br />

      4. <a href="http://angrau.ac.in/angrau/angrau_admissions/File_4new.pdf">&quot;NCC Quota - Provisional Priority List&quot;</a><br />

      5. <a href="http://angrau.ac.in/angrau/angrau_admissions/File_5new.pdf">&quot;Sports Certificate Verification</a><br />

      6. <a href="http://angrau.ac.in/angrau/angrau_admissions/File_6new.pdf">&quot;AGRICET 2019 : Application Form for Admission into BSc(Hons) Agriculture</a></p>

      <p>&nbsp;</p>

<br />

        </p>

      </p>

    <p><br />

        </p>

    <p>&nbsp;</p></td>

  </tr>

</table>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>



  </script>



  



  



  <?php include "footer.php"; ?>



</p>



<p>&nbsp;</p>



<p>&nbsp; </p>



